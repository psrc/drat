## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ----customize_via_ggplot_example1, message=FALSE-----------------------------
library(psrcplot)
library(dplyr)

passenger_volume <- enplanement_example_data %>% 
                       filter(loc_id=="SEA") %>% 
                       mutate(data_year=as.character(data_year))

static_plot <- static_line_chart(t=passenger_volume, 
                       x='data_year', y='enplanements', fill='airport_name',
                       title="Sea-Tac passengers (annual total)",
                       lwidth = 1.5,
                       breaks = seq(2006, 2018, 4))

static_plot

## ----customize_via_ggplot_example2, message=FALSE-----------------------------
static_rev <- static_plot + ggplot2::scale_y_continuous(
                                limits=c(0,25e6), 
                                labels=scales::unit_format(unit="M", scale=1e-6)) + 
                            ggplot2::guides(color="none")

static_rev

## ----make_interactive_example, eval = FALSE, message=FALSE--------------------
# interactive_plot <- static_rev %>% psrcplot::make_interactive()
# 
# interactive_plot

