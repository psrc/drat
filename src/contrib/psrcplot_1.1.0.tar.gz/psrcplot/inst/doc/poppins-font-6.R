## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----mode_data, message=FALSE-------------------------------------------------

"Poppins" %in% sysfonts::font_files()$family

