## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----transit_access_data, message=FALSE---------------------------------------
library(ggplot2)
library(psrcplot)
library(dplyr)

transit_access <- transit_access_example_data %>% select(-c("survey","sample_size"))

head(transit_access)

## ----interactive_plot_transit_access, message=FALSE---------------------------
transit_access_chart <- interactive_column_chart(
                            t=transit_access, 
                            x='mode_acc_walk', y='share', fill='year', 
                            moe='share_moe', est='percent',
                            color="psrc_light", title='Transit Access Mode')
transit_access_chart

## -----------------------------------------------------------------------------
htmlwidgets::saveWidget(transit_access_chart, file=('transit_access.html'))


