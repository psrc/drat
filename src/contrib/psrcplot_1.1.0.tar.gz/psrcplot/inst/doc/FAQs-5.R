## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ----example_data_retrieval, message=FALSE------------------------------------
# library(magrittr)
# library(psrccensus)
# library(dplyr)
# 
# # Retrieve, summarize and filter Census PUMS data
#   z_2019<- get_psrc_pums(span=5,
#                          dyear=2019,
#                          level='h',
#                          vars=c("HRACE", "HINCP"))
#   
#   hhinc19_x_race <- psrc_pums_median(
#                           z_2019, 
#                           stat_var="HINCP",
#                           group_vars="HRACE")


## ----default_ordering, message=FALSE------------------------------------------
library(magrittr)
library(dplyr)
library(psrcplot)
  
hhinc19_x_race <- psrcplot::summary_pums_example_data %>%
     filter(HRACE !="Total") %>% mutate(DATE=as.character(DATA_YEAR))

# Create chart -- default category ordering   
income.chart.default <- static_bar_chart(
     t=hhinc19_x_race,
     x="HINCP_median", y="HRACE",
     fill="DATE",
     moe='HINCP_median_moe',
     est='currency',
     title="Median Household Income by Race - default Race order")

income.chart.default


## ----reverse_ordering, message=FALSE------------------------------------------
hhinc19_rev <- hhinc19_x_race %>% 
  mutate(HRACE_REV=forcats::fct_rev(as.factor(HRACE)))

income.chart.reverse <- static_bar_chart(
     t=hhinc19_rev, 
     x="HINCP_median", y="HRACE_REV",
     f="DATE",
     moe='HINCP_median_moe',
     est='currency',
     title="Median Household Income by Race - reverse default")

income.chart.reverse


## ----data_ordering, message=FALSE---------------------------------------------
 hhinc19_low_high <- hhinc19_x_race %>% 
  mutate(HRACE_low_high=forcats::fct_reorder(HRACE, -HINCP_median))

income.chart.low_high <- static_bar_chart(
      t=hhinc19_low_high, 
      x="HINCP_median", y="HRACE_low_high",
      fill="DATE",
      moe='HINCP_median_moe',
      color='psrc_dark',
      est='currency',
      title="Median Household Income by Race - median income order")

income.chart.low_high


## ----custom_ordering, message=FALSE-------------------------------------------
hhinc19_custom <- hhinc19_x_race %>%
    mutate(HRACE_custom=factor(HRACE, 
       levels = c("American Indian or Alaskan Native Alone", 
                  "Asian alone",
                  "Black or African American alone",
                  "Hispanic or Latino",
                  "Native Hawaiian and Other Pacific Islander alone",
                  "White alone",
                  "Some Other Race alone",
                  "Two or More Races", 
                  "Multiple Races")))

income.chart.custom <- static_bar_chart(
      t=hhinc19_custom, 
      x="HINCP_median", 
      y="HRACE_custom",
      fill="DATE",
      moe='HINCP_median_moe',
      color='psrc_dark',
      est='currency',
      title= "Regional Household Median Income by Race - custom order")

income.chart.custom


## ----wrap_labels, message=FALSE-----------------------------------------------

income.column.wrapped <- income.chart.custom + 
  ggplot2::scale_x_discrete(labels=function(x) stringr::str_wrap(x, width=25)) +
  ggplot2::ggtitle("Regional Household Median Income by Race - wrapped label")

income.column.wrapped


## ----reference_line, message=FALSE--------------------------------------------
ref_val <- summary_pums_example_data %>% filter(HRACE=="Total") %>% pull(HINCP_median) %>% round()

income.column.refline <- income.column.wrapped +
                          ggplot2::geom_hline(yintercept= ref_val, 
                                              linetype='dotdash', 
                                              linewidth=1, 
                                              show.legend = FALSE, 
                                              color='#00716c') +
                          ggplot2::annotate("text", 
                                            y=ref_val+5000, 
                                            x=6, 
                                            label="Region",
                                            angle='270', 
                                            color='#00716c')

income.column.refline

