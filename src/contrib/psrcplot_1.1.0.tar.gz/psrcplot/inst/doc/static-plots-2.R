## ----setup, include=FALSE, echo=FALSE-----------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----mode_data, message=FALSE-------------------------------------------------
library(psrcplot)
library(dplyr)
library(ggplot2)

mode_shares <- mode_share_example_data %>% 
 filter(Category=="Mode to Work by Race" & Geography=="Region" & Race=="Total") %>%
 select(-c(Category, Geography, Race)) %>% mutate(Year = as.character(Year))

head(mode_shares)

## ----static_plot_modes, message=FALSE-----------------------------------------
modes_chart <- static_bar_chart(
                    t=mode_shares, y="Mode",x="share", fill="Year",
                    title="Mode Share to Work",
                    alt="Chart of Work Mode Shares",
                    source=paste("Source: ACS 5-Year Estimates, table B3002",
                                 "for King, Kitsap, Pierce and Snohomish counties.",
                                 sep = "\n"),
                    color="pgnobgy_5")

modes_chart

## -----------------------------------------------------------------------------
ggsave(filename='modes_bar_chart.png', plot=modes_chart, device='png')


