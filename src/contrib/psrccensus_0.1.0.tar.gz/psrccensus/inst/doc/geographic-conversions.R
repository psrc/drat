## ----setup, include=FALSE, echo=FALSE, message=FALSE, warning=FALSE-----------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(magrittr)
library(knitr)
library(psrccensus)

## ----simple geographic conversion, message=FALSE------------------------------
library(psrccensus)
library(magrittr)

x <- get_acs_recs(geography = 'block group',
                  table.names = 'B03002',
                  years = 2021,
                  acs.type = 'acs5') %>% 
  dplyr::mutate(label=stringr::str_replace_all(label,"(^Estimate!!|Total:!!)",""))

x %>% dplyr::filter(variable=="B03002_012") %>% .[,c(1,5:8)] %>% head()

rgc_race <- census_to_rgc(x)

rgc_race %>% dplyr::filter(variable=="B03002_012") %>% .[,c(1,3,7:8)] %>% head()

                          

## ----convert group quarters, message=FALSE------------------------------------

y <- get_acs_recs(geography = 'tract',
                  table.names = 'B26001',
                  years = 2019,
                  acs.type = 'acs5') %>% 
  dplyr::mutate(label=stringr::str_replace_all(label,"(^Estimate!!|Total:!!)",""))

y %>% .[,c(1,5:8)] %>% head()

rgc_gq_age <- census_to_rgs(y, wgt="group_quarters_pop")

rgc_gq_age %>% .[,c(1,3,4,7,8)]



