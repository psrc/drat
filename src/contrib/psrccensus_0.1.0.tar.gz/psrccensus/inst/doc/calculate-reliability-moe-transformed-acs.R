## ----setup, include=FALSE, echo=FALSE, message=FALSE, warning=FALSE-----------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(magrittr)
library(knitr)
library(psrccensus)

## ----include=TRUE, echo=FALSE-------------------------------------------------
library(psrccensus)
library(tidycensus)
library(dplyr)
library(tidyr)

## -----------------------------------------------------------------------------
# Finding the corresponding ACS table - this works if you know the correct concept label. If not, another option would be to visit https://data.census.gov/table and search for the right subject table and skip to the next step ----
#x <- tidycensus::load_variables(2021,"acs5") %>% 
# dplyr::filter(grepl("percent",
#                    concept, ignore.case=TRUE) & 
#               (geography=="tract"))

# getting data by tract
acs_data <- get_acs_recs(geography ='tract', 
                         table.names = 'B25070', #subject table code
                         years = 2022,
                         acs.type = 'acs5')

## -----------------------------------------------------------------------------
# data wrangling for grouping >30% and under 30% - census tract and population
acs_data <- acs_data %>% rename_at('label', ~'rent_burden')

# Create variables
acs_data <- acs_data %>% 
  mutate(rent_burden_group=factor(
    case_when(grepl("Less than 10.0 percent|10.0 to 14.9 percent|15.0 to 19.9 percent|
                    20.0 to 24.9 percent|25.0 to 29.9 percent", rent_burden) ~
                    "Less than 30 percent",
              grepl("30.0 to 34.9 percent|35.0 to 39.9 percent|35.0 to 39.9 percent|
                    40.0 to 49.9 percent|50.0 percent or more", rent_burden) ~ 
                  "Cost Burdened (More than 30 percent)",
              grepl("Not computed", rent_burden) ~ "Not computed",
              !is.na(rent_burden) ~ "Total")))

## -----------------------------------------------------------------------------
# filter only fields of interest - census tract and estimate

# use the moe_sum function from tidycensus
acs_data_group <- acs_data %>% 
  dplyr::summarise(estimate=sum(estimate), 
                   moe=tidycensus::moe_sum(estimate=estimate, moe=moe),
                   .by = c(GEOID, rent_burden_group))


## -----------------------------------------------------------------------------
# pivot data to calculate percentage by census tract, calculate estimates

acs_data_group<- acs_data_group %>%   
  pivot_wider(names_from = rent_burden_group, values_from = c(estimate,moe))%>%
  rename('estimate_cost_burdened'='estimate_Cost Burdened (More than 30 percent)',
         'moe_cost_burdened'= 'moe_Cost Burdened (More than 30 percent)')

# weight averages for population & calculating percentage/share of population per tract instead of integer
acs_data_group<-  acs_data_group %>%
  mutate(estimate_new_total=(estimate_Total-`estimate_Not computed`))%>%
  mutate(estimate_perc_cost_burdened=((estimate_cost_burdened/estimate_new_total)))

## -----------------------------------------------------------------------------
#calculate moes
acs_data_group <- acs_data_group %>%
  rowwise()%>%
  mutate(moe_new_total=moe_sum(estimate=c(estimate_Total, `estimate_Not computed`), 
                               moe=c(moe_Total,`moe_Not computed`)))%>%
  mutate(moe_perc_cost_burdened=moe_prop(num=estimate_cost_burdened,
                              denom=estimate_new_total, moe_num=moe_cost_burdened, moe_denom=moe_new_total))


acs_data_final<- acs_data_group %>% 
  dplyr::select(GEOID, estimate_cost_burdened, estimate_new_total, estimate_perc_cost_burdened,
                moe_cost_burdened, moe_new_total, moe_perc_cost_burdened) %>%
  dplyr::filter(!is.na(estimate_cost_burdened))

acs_data_final<-reliability_calcs(acs_data_final, estimate='estimate_perc_cost_burdened', 
                                  moe='moe_perc_cost_burdened')

head(acs_data_final%>%select(GEOID, estimate_perc_cost_burdened, reliability))

