## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(psrccensus)
library(dplyr)

## ----acs examples, message=FALSE----------------------------------------------
x <- get_acs_recs(geography = 'county',
                  table.names = 'B03002',
                  years = 2019,
                  acs.type = 'acs1')

head(x)


## ----census examples, message=FALSE-------------------------------------------
y <- get_decennial_recs(geography = 'msa',
                        table_codes = c("H001", "P001"),
                        years = c(2010),
                        fips = c('42660', "28420"))

head(y)


