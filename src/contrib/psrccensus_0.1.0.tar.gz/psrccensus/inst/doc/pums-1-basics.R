## ----setup, include=FALSE, echo=FALSE, message=FALSE, warning=FALSE-----------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(magrittr)
library(knitr)
library(psrccensus)

## ----median, message=FALSE, warning=FALSE, eval=TRUE--------------------------
library(psrccensus)
dir <- "J:/Projects/Census/AmericanCommunitySurvey/Data/PUMS/pums_rds"

x <- get_psrc_pums(span = 5,                     # Denoting ACS 5-year estimates; 1-year also available
                   dyear = 2019,                 # Last data year of span
                   level = "h",                  # Unit of analysis == household ("p" used for person)
                   vars = c("HINCP","OWN_RENT"), # PUMS household income & housing tenure variables; using tenure later. 
                   dir=dir)                      # Using local directory (due to Census FTP restriction)

psrc_pums_median(x, stat_var = "HINCP")          # Median Household income (without regard to tenure)

## ----median by category, message=FALSE, warning=FALSE, , eval=TRUE------------
psrc_pums_median(x,                              # the assigned result of get_psrc_pums()
                 stat_var = "HINCP",             # Summarizing household income . . .
                 group_vars = "OWN_RENT",        # . . . grouped by housing tenure
                 rr=TRUE)                        # w/ optional relative reliability measure

## ----count by category, message=FALSE, warning=FALSE, , eval=TRUE-------------
psrc_pums_count(x, group_vars=c("COUNTY","OWN_RENT"))      # If omitting stat_var argument, group_var must be labeled

## ----summary by category, message=FALSE, eval=FALSE---------------------------
# psrc_pums_summary(x, "HINCP", "OWN_RENT") %>% dplyr::select(-c("DATA_YEAR","COUNTY"))

## ----z score calculation, message=FALSE, warning=FALSE, , eval=TRUE-----------
rs <- psrc_pums_median(x, "HINCP", "OWN_RENT")
c1 <- as.numeric(rs[1, c("HINCP_median", "HINCP_median_moe")])
c2 <- as.numeric(rs[3, c("HINCP_median", "HINCP_median_moe")])
z_score(c1, c2)                     # Returns one z-score per row pair

