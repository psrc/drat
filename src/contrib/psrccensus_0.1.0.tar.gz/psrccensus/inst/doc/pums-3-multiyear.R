## ----setup, include=FALSE, echo=FALSE, message=FALSE, warning=FALSE-----------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(magrittr)
library(knitr)
library(psrccensus)

## ----apply function across PUMS years, message=FALSE, eval=FALSE--------------
# library(psrccensus)
# library(magrittr)
# library(dplyr)
# dir <- "J:/Projects/Census/AmericanCommunitySurvey/Data/PUMS/pums_rds"
# 
# # Build a single year function first
# # -- it can include as many individual stat analyses as needed (see list items at end)
# # -- notice `real_dollars()` creates the variable HINCP2020 later used for median statistic
# 
# pums_singleyear <- function(dyear, span=1){
#   hh_df <- get_psrc_pums(span, dyear, "h", c("HINCP","AGEP","HRACE","LNGI","SCHL"), dir=dir)
#   hh_df %<>% real_dollars(2020) %>% mutate(
#     ed_attain = factor(case_when(grepl("(Bach|Mast|Prof|Doct)", SCHL)  ~ "Bachelor's degree or higher",
#                                  !is.na(SCHL)                          ~ "Less than a Bachelor's degree")),
#     lmtd_engl = factor(case_when(grepl("^No one", LNGI) ~ "Limited English proficiency",
#                                  !is.na(LNGI)           ~ "English proficient")))
#   dvars <- c("HRACE","lmtd_engl","ed_attain") %>% as.list()
#   singleyr_rs <- list()
#   singleyr_rs[[1]] <- pums_bulk_stat(hh_df, "count", group_var_list=dvars, incl_na=FALSE)
#   singleyr_rs[[2]] <- pums_bulk_stat(hh_df, "median", "HINCP2020", dvars, incl_na=FALSE)
# # singleyr_rs[[3]] <- ...
#   return(singleyr_rs)
# }
# 
# # Multiyear function runs the single-year function across years and combines results
# pums_multiyear <- function(dyears){
#   multiyear_rs <- lapply(dyears, pums_singleyear) %>% lapply(as.vector) %>%
#     do.call(rbind, .) %>% as.data.frame() %>% lapply(data.table::rbindlist)
#   return(multiyear_rs)
# }
# 
# x <- pums_multiyear(2015:2019)
# 

