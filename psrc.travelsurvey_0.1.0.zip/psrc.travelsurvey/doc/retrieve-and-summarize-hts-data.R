## ----include = FALSE, eval=TRUE-----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
suppressWarnings(library(psrc.travelsurvey))

## ----varsearch, message=FALSE, eval=FALSE-------------------------------------
# View(psrc_hts_varsearch("\\bmode\\b"))

## ----variable_list, message=FALSE, eval=FALSE---------------------------------
# View(psrc.travelsurvey:::variable_list)

## ----retrieve_and_summarize, message=FALSE, eval=TRUE-------------------------
library(psrc.travelsurvey)
library(data.table)

# Specify which variables to retrieve
vars <- c("hhsize", "employment", "commute_mode", "dest_purpose",
          "mode_class_5", "distance_miles")

# Retrieve the data
hts_data <- get_psrc_hts(survey_vars = vars, survey_year=2025)  # default includes all survey_years
  
# Calculate a numeric summary, i.e. min/max/median/mean
rs1 <- psrc_hts_stat(hts_data,
                     analysis_unit = "trip",
                     group_vars = "hhsize",
                     stat_var = "distance_miles",
                     incl_na = FALSE)

head(dplyr::select(rs1, -c(survey_year, min, max)))

# Calculate a categorical summary, i.e. count/share
rs2 <- psrc_hts_stat(hts_data, "trip", c("hhsize", "mode_class_5"))

head(dplyr::select(rs2[as.character(mode_class_5)=="Transit"],
                   -c(survey_year, mode_class_5)))

## ----add_variable, message=FALSE, eval=TRUE-----------------------------------
library(dplyr)
library(stringr)

# Use a standard variable recode to get simpler trip purpose
hts_data <- hts_bin_dest_purpose(hts_data)

# Use dplyr::mutate to add a simplified mode field & work purpose specifier
hts_data$trip <- mutate(
  hts_data$trip, 
  purpose_work = case_when(
    dest_purpose_bin4=="Work" ~ "Work",
    !is.na(dest_purpose_bin4) ~ NA_character_)
) 

# Calculate a categorical summary, i.e. count/share
rs3 <- psrc_hts_stat(hts_data, "trip", c("purpose_work", "mode_class_5"), incl_na=FALSE)

head(dplyr::select(rs3,
                   -c(survey_year, purpose_work)))


