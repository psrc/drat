## ----include = FALSE, eval=TRUE-----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
suppressWarnings(library(psrc.travelsurvey))

## ----retrieve_sss, message=FALSE, eval=FALSE----------------------------------
# library(psrc.travelsurvey)
# library(magrittr)
# library(dplyr)
# 
# vars <- c("employment", "crash_participant", "travel_anxiety", "safety_choices", "crash_number_people")
# 
# sss_data <- get_psrc_sss(survey_vars = vars)

## ----sss_cat, message=FALSE, eval=FALSE---------------------------------------
# rs1 <- psrc_sss_stat(
#   sss_data,
#   group_vars = c("crash_participant", "travel_anxiety"),
#   incl_na = FALSE
# )
# 
# head(rs1)

## ----sss_num, message=FALSE, eval=FALSE---------------------------------------
# sss_data <- mutate(sss_data, crash_number_people_numeric = if_else(
#     is.na(crash_number_people), NA_integer_, as.integer(stringr::str_extract(crash_number_people, "^\\d+"))))
# 
# rs2 <- psrc_sss_stat(
#   sss_data,
#   group_vars = "crash_participant",
#   stat_var = "crash_number_people_numeric",
#   incl_na = FALSE
# )
# 
# head(rs2)

