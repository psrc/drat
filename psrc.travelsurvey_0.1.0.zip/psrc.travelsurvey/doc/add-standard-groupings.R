## ----include = FALSE, eval=TRUE-----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(psrc.travelsurvey)

## ----example, message=FALSE, eval=TRUE----------------------------------------
library(psrc.travelsurvey)
library(magrittr)
library(data.table)

# Specify which variables to retrieve
vars <- c("age", "hhsize")

# Retrieve the data
hts_data <- get_psrc_hts(survey_year=2025, survey_vars = vars) 

# Add standard groupings for age and household size
# -- Notice age and hhsize use different tables (person, hh)
# -- but you don't need to worry about that; the package knows
hts_data <- hts_data %>% 
  hts_bin_age() %>%
  hts_bin_hhsize()

hts_data$person[, head(.SD), .SDcols=patterns("^age")]


