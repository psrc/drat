## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ----search, include=TRUE-----------------------------------------------------
shhh <- suppressPackageStartupMessages
shhh(library(psrcctpp))
shhh(library(magrittr))
shhh(library(dplyr))
shhh(library(stringr))

ctpp_tblsearch("?2", "means of transp", year=2021) %>%
  mutate(desc=str_replace(description, "by Means .*", "bmtw")) %>%
  select(c(name, desc)) %>% head()


## ----retrieval, include=TRUE--------------------------------------------------
x <- get_psrc_ctpp("tract", "B202105", 2021)            # get data

mutate(x, tract=str_extract(work_label, "[\\.\\d]+")) %>%  # fit in frame
  select(10, 7:8) %>% filter(tract=="82") %>% head()                   


## ----summation, include=TRUE--------------------------------------------------
x %<>% mutate(
  custom_geo=case_when(
     str_sub(work_geoid,4L,11L) %in% paste0("3302380",3:4)         ~ "Downtown Bellevue",
     str_sub(work_geoid,4L,11L) %in% paste0("61040",c(4,7:8),"00") ~ "Downtown Everett",
     TRUE                                                          ~ NA_character_),
  category=factor(
    case_when(
      grepl(" carpool$",                category) ~"Carpool",
      grepl("Drove alone|Motorcycle",   category) ~"Drove Alone",
      grepl("Bus|Subway|Ferry|[rR]ail", category) ~"Transit",
      grepl("Bicycle|Walked",           category) ~"Bike/Ped",
      grepl("^Total, means",            category) ~"Total",
      grepl("Other|Taxi",               category) ~"Other",
      !is.na(category) ~category),
    levels=c("Bike/Ped","Transit","Carpool","Drove Alone","Other","Total")))
rs <- psrc_ctpp_sum(x, group_vars="custom_geo", incl_na=FALSE) %>% ctpp_shares()
head(rs[,2:7])


