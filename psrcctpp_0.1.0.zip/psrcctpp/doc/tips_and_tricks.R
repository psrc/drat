## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ----query.variables, include=TRUE--------------------------------------------
shhh <- suppressPackageStartupMessages
shhh(library(psrcctpp))
shhh(library(magrittr))
shhh(library(dplyr))
shhh(library(stringr))

ctpp_varsearch("A101101", year=2016) %>% head()

x <- get_psrc_ctpp(scale="tract", 
                   table_code=c("A101101_e1","A101101_e2"), # Variable list instead of table
                   dyear=2016)

mutate(x, res_label=str_sub(res_label, 7L, 14L),           # abbreviate to fit in frame
          category =str_sub(category, 1L, 15L)) %>%
  select(c(3,6:8)) %>% head()                   


## ----filepath, include=TRUE---------------------------------------------------
y <- get_psrc_ctpp("tract", "A101101", 2016, filepath="default")

mutate(y, res_label=str_sub(res_label, 7L, 14L),    # abbreviate to fit in frame
          category =str_sub(category, 1L, 15L)) %>%
  select(c(3,6:8)) %>% head()    


